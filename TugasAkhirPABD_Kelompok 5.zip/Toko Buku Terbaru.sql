create database TOKOBUKUBARU


create table Suppliers(
id_supplier char (5) primary key not null,
kode_buku char(9) foreign key references BukuKu (kode_buku),
nama_supplier varchar (40),
alamat_supplier varchar (50),
telp_supplier numeric (13));

create table BukuKu(
kode_buku char (9) primary key not null,
id_toko char (5)  not null,
id_supplier char  (5)  not null,
judul_buku varchar (30) not null,
tahun_terbit varchar (10)  not null,
rak_buku varchar (5) not null,
harga_buku varchar (20),
penulis varchar (40));

select * from BukuKu
select * from Suppliers
